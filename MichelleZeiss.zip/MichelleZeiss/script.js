var mydata = JSON.parse(data);
var article = document.querySelector('#main');
var template = document.querySelector('template');
var cartemp = document.querySelector('#cartemp');
var tabletemp = document.querySelector('#tabletemp');

// adds table of contents link
var tocLink = function(links, nav) {
    obj = {};
    obj.index = -1;
    obj.prev = null;
    obj.next = links;
    obj.type = 'tableofcontents';
    obj.name = 'null';
    obj.path = '';
    obj.nav = nav;

    links.prev = obj;
    return obj;
}

// creates linked list of media objects
var linkBuilder = function(data) {
    var prev = null;
    index = 0;
    var origin = null;
    for (var array of data) {
        var obj = {};
        if (!origin) {
            origin = obj;
        }
        if (prev) {
            prev.next = obj;
        }
        obj.index = index;
        obj.prev = prev;
        obj.next = null;
        obj.type = array[0].split('::')[0];
        obj.name = array[0].split('::')[1];
        obj.path = array[1];
        prev = obj;
        index++;
    }
    return origin;
}

// builds navigation batrs based on file directories found in json
var navBuilder = function(data, prev = null, home = false, title = null) {
    if (Object.keys(data).every(item => item.includes('_media'))) {
        return tocLink(linkBuilder(data._media), prev);
    }
    var nav = template.content.cloneNode(true).querySelector('NAV');
    nav.prev = prev;
    nav.current = null;
    nav.media = null;
    let buttons = [];
    if (title) {
        let button = document.createElement('BUTTON');
        button.textContent = title;
        button.className = 'title';
        buttons.push(button);
    }
     for (let [key, value] of Object.entries(data)) {
        if (key.includes('_media')) {
            nav.media = linkBuilder(value);
        }
        else {
            let next = navBuilder(value, nav, false, key.split('_').join(' '));
            let button = document.createElement('BUTTON');
            button.next = next;
            button.nav = nav;
            button.textContent = key.split('_').join(' ');
            button.addEventListener("click", (e)=> {
                dirPress(nav, button, button.next);
            });
            buttons.push(button);
        }
    }
    nav.back = nav.querySelector('#back');
    nav.back.addEventListener("click", (e)=> {mediaSelect(nav, nav.current.prev);});
    nav.forward = nav.querySelector('#forward');
    nav.forward.addEventListener("click", (e)=> {mediaSelect(nav, nav.current.next);});
    nav.querySelector('#home').addEventListener("click", (e)=> {dirPress(nav, null, document.querySelector('#navhome'));});
    nav.prepend(...buttons);
    document.body.append(nav);
    if (home && nav.media) {
        mediaSelect(nav, nav.media);
    }
    if (home) {
        nav.id = 'navhome';
        nav.hidden = false;
        nav.querySelector('#home').hidden = true;
    }
    return nav;
}

// action when a dirctory button is pressed on the nav bar
var dirPress = function(nav, button, next) {
//    document.querySelectorAll('.display').forEach(display => {display.hidden = true;});
    document.querySelectorAll('.clicked').forEach(element => {element.classList.remove('clicked');});
    if (button) {
        button.classList.add('clicked');
    }
    nav.current = null;
    if (next.nodeName === 'NAV') {
        next.hidden = false;
        mediaSelect(next, next.media);
        nav.hidden = true;
        nav.forward.hidden = true;
        nav.back.hidden = true;
//        mediaSelect(nav);
    }
    else {
        nav.forward.hidden = false;
        nav.back.hidden = false;
        mediaSelect(nav, next);
    }

}

// action when media needs to be displayed
var mediaSelect = function(nav, data = null, carousel = false, show = true) {
    if (!carousel) {
        document.querySelectorAll('.display').forEach(current => {
            current.hidden = true;
            current.toggle(0);
        });
    }
    else if (carousel.current) {
        carousel.current.hidden = true;
    }
    if (!data) {
        return;
    }
    nav.current = data;
    if (!data.prev) {
        nav.back.hidden = true;
    }
    else {
        nav.back.hidden = false;
    }
    if (!data.next) {
        nav.forward.hidden = true;
    }
    else {
        nav.forward.hidden = false;
    }
    element = mediaSearch(data);
    element.hidden = false;
    if (carousel) {
        element.className = 'cardisplay'
        carousel.querySelector('#carmain').prepend(element);
        carousel.current = element;
    }
    else {
        article.append(element);
    }
    return element;
}

// finds existing, or creates new media HTML object
var mediaSearch = function(data) {
    found = document.getElementById(data.path);
    if (found) {
        found.toggle(1);
        return found;
    }
    var path = data.path;
    if (data.type.includes('carousel')) {
        var element = cartemp.content.cloneNode(true).querySelector('#carousel');
        var nav = element.querySelector('nav');
//        nav.querySelector('#carnavtext').textContent = data.type.split('::')[1].split('_').join(' ');
        data = linkBuilder(path);
        nav.back = nav.querySelector('#back');
        nav.forward = nav.querySelector('#forward');
        mediaSelect(nav, data, element);
        nav.back.addEventListener("click", (e)=> {mediaSelect(nav, nav.current.prev, element);});
        nav.forward.addEventListener("click", (e)=> {mediaSelect(nav, nav.current.next, element);});
        element.toggle = function(status) {this.remove();};
        path = 'carousel';
    }
    else if (data.type.includes('image')) {
        var element = document.createElement('IMG');
        element.src = data.path;
        element.toggle = function(status) {};
    }
//    else if (data.type.includes('pdf')) {
//        //https://developer.adobe.com/document-services/apis/pdf-embed/
//    }
    else if (data.type.includes('video')) {
        var element = document.createElement('VIDEO');
//        element.width="320"
//        element.height="240";
        element.autoplay = true;
        element.controls = true;
        var source = document.createElement('SOURCE');
        source.type = data.type;
        source.src = data.path;
        element.append(source);
        element.toggle = function(status) {
            if (status) {
                this.load();
            }
            else {
                this.pause();
            }
        }
    }
    else if (data.type.includes('tableofcontents')) {
        var element = tabletemp.content.cloneNode(true).querySelector('#tableofcontents');
        var nav = data.nav;
        while (data.next) {
            data = data.next;
            let button = document.createElement('BUTTON');
            button.textContent = data.name;
            button.addEventListener("click", (e)=> {mediaSelect(nav, data);});
            element.append(button);
            path = 'tableofcontents'
        }
        element.toggle = function(status) {this.remove();};
    }
    element.classList.add('display');
    element.id = path;
    return element;
}

home = navBuilder(mydata, null, true);

