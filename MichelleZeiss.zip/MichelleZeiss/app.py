import os
import mimetypes
from pathlib import PurePath
import json
import re

path = PurePath('C:/Users/Player/Desktop/Zeiss Media')

#https://stackoverflow.com/a/62042413
#https://stackoverflow.com/a/69644244


def clean_name(name):
    matches = re.findall(r'[a-zA-Z]+', name)
    return "_".join([s for s in matches])

def send_to_json(path, depth=1):
    json_obj = {}
    with os.scandir(path) as directory:
        # sort by number in beginning, or alpha
        for f in sorted(directory, key=lambda f: f.name):
            if f.is_dir():
                result = send_to_json(f.path, depth + 1)
                if result:
                    if depth > 2:
                        if not json_obj.get('_media', None):
                            json_obj['_media'] = []
                        json_obj['_media'].append(['carousel::' + clean_name(f.name), result['_media']])
                    else:
                        json_obj[clean_name(f.name)] = result
            else:
                media = mimetypes.guess_type(f.name)
                if media and 'image' in media[0] or 'video' in media[0]:
                    media = media[0]
                    if not json_obj.get('_media', None):
                        json_obj['_media'] = []
                    json_obj['_media'].append([media + '::' + clean_name(f.name), PurePath(f.path).as_uri()])
    return json_obj

output = send_to_json(path)
with open('dump.js', 'w') as f:
    f.write("data = '" + json.dumps(output) + "'")




